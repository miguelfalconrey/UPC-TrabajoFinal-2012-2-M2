/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package appfiguras;

/**
 *
 * @author alumnos
 */
public abstract class Figura {
    public abstract double calcularArea();
   
}
