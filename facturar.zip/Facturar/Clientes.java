public class Clientes
{
	String Cedula;
	String Cliente;
	String FechaCompra;
	float ValorCompra;	
	  public Clientes(String ced,String Cli,String fec, float vc)
	     {
	     	Cedula=ced;
	       	Cliente=Cli;
	       	FechaCompra=fec;
	       	ValorCompra=vc;
	     }
}